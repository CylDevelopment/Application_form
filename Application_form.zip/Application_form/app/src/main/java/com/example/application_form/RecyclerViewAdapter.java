package com.example.application_form;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {
    private Context ncontext;
    private List<Aadhar> ndata;

    public RecyclerViewAdapter(Context ncontext, List<Aadhar> ndata) {
        this.ncontext = ncontext;
        this.ndata = ndata;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        LayoutInflater inflater = LayoutInflater.from(ncontext);
        view = inflater.inflate(R.layout.cardview_item_book,viewGroup,false);
        return new MyViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {


        myViewHolder.tv_aadhar_title.setText(ndata.get(i).getTitle());
        myViewHolder.img_book_thumbnail.setImageResource(ndata.get(i).getThumbmail());

    }

    @Override
    public int getItemCount() {
        return ndata.size();
    }

    public static class MyViewHolder extends  RecyclerView.ViewHolder {
        TextView tv_aadhar_title;
        ImageView img_book_thumbnail;

    public MyViewHolder(View itemView){
        super(itemView);
        tv_aadhar_title = (TextView) itemView.findViewById(R.id.Aadhar_Card_id);
        img_book_thumbnail = (ImageView) itemView.findViewById(R.id.Aadhar_img_id);
    }
}
}
